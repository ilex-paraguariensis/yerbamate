from .node import Node
from .utils.bunch import Bunch
from typing import Optional, Any, Callable, Type, Union
import ipdb


class NodeDict(Node):

    @staticmethod
    def create(root_module:str, base_module:str, key_value_map:dict, params):
        Node.set_config(base_module, root_module, key_value_map)
        return NodeDict(params)

    def __init__(self, args, **kawrgs) -> None:
        assert isinstance(args, dict), f"args must be a dict, not {type(args)=}"
        super().__init__(args, **kawrgs)

    def __load__(self, parent: Optional[Node] = None):

        # ipdb.set_trace()
        node_key_dict = {}
        for key, val in self.__dict__.items():

            if not key.startswith("_") and key in self._original_keys:
                val = load_node(val, parent=self)
                if isinstance(val, Node):
                    val.__load__(self)
                    setattr(self, key, val)
                    node_key_dict[key] = val
                elif isinstance(val, list):
                    for i, item in enumerate(val):
                        item = load_node(item, parent=self)
                        if isinstance(item, Node):
                            item.__load__(self)
                            val[i] = item

        for key, val in node_key_dict.items():
            setattr(self, f"{key}_node", val)

        # self.load_dynamic_objects()

        return self

    def __call__(self, *args: Any, **kwds: Any) -> Any:

        self.load_dynamic_objects()

        def val_to_call(val):
            if isinstance(val, Node):
                return val()
            elif isinstance(val, list):
                return [val_to_call(item) for item in val]
            else:
                return val

        result = {
            key: val_to_call(val)
            for key, val in self.__dict__.items()
            if not key.startswith("_") and key in self._original_keys
        }
        return result


class ObjectReference(Node):
    reference_key: str = ""
    _reference: Optional[Node] = None

    def __init__(self, args, parent: Optional[Node] = None, **kawrgs) -> None:
        super().__init__(args, parent=parent, **kawrgs)

    def __call__(self, *args: Any, **kwds: Any) -> Any:
        return Node._key_value_map[self.reference_key]


class MethodCall(ObjectReference):
    function_call: str = ""
    reference_key: Optional[str] = None
    params: Bunch = Bunch({})

    def __call__(self, parent: Optional[object] = None, *args, **kwargs):

        if self._py_object != None:
            return self._py_object

        # first create DictNode of params
        dictNode = NodeDict(self.params)
        dictNode.__load__(self)
        params = dictNode()
        # print("method call params", params)

        # then call the function
        object = Node._key_value_map[self.reference_key]
        function = getattr(object, self.function_call)
        self._py_object = function(**params)
        self.post_object_creation()
        return self._py_object

    def __init__(self, args, parent: Optional[object] = None):
        super().__init__(args)


class YetAnotherMethodCall(MethodCall):
    function: str = ""
    object_key: str = ""
    params: Bunch = Bunch({})

    def __call__(self, parent: Optional[object] = None, *args, **kwargs):

        if self._py_object != None:
            return self._py_object

        # first create DictNode of params
        dictNode = NodeDict(self.params)
        dictNode.__load__(self)
        params = dictNode()
        # print("method call params", params)
        # ipdb.set_trace()

        # then call the function
        object = Node._key_value_map[self.reference_key]
        function = getattr(object, self.function)
        self._py_object = function(**params)
        self.post_object_creation()
        return self._py_object

    def __init__(self, args, parent: Optional[object] = None):
        super().__init__(args)


# Methodcall for objects
class AnonMethodCall(Node):
    function: str = ""
    params: Bunch = Bunch({})

    def __load__(self, parent=None) -> object:

        self._node = NodeDict(self.params)
        return self

    def __call__(self, *args, **kwargs):
        return self._node()


class FunctionModuleCall(Node):
    function: str = ""
    module: str = ""
    params: Bunch = Bunch({})
    method_args: Optional[list[AnonMethodCall]] = None

    def __load__(self, parent=None) -> object:

        self._param_node = NodeDict(self.params)
        self._param_node.__load__(self)
        return self

    def __call__(self):

        params = self._param_node()

        module = self.load_module()

        function = getattr(module, self.function)

        _arg, _kwarg = flatten_nameless_params(params)

        if _arg:
            self._py_object = function(*_arg, **_kwarg)
        else:
            self._py_object = function(**params)
        self.post_object_creation()
        return self._py_object

    def call_method(self, method_name: str, *args, **kwargs):
        method_arg_names = [arg["function"] for arg in self.method_args]
        assert method_name in method_arg_names

        idx = method_arg_names.index(method_name)
        method_args = self.method_args[idx]["params"]

        method_args = load_node(method_args, parent=self)
        # ipdb.set_trace()
        method_args.__load__(self)
        method_args = method_args()
        f, p = flatten_nameless_params(method_args)

        method = getattr(self._py_object, method_name)
        return method(*args, *f, **p, **kwargs)


def flatten_nameless_params(params: dict) -> dict:

    flat = params.pop("", None)
    flats = []
    while flat != None:
        flats.append(flat)
        flat = params.pop("", None)

    return flats, params


class Object(Node):
    module: str = ""
    class_name: str = ""
    params: Bunch = Bunch({})  # param is actualy a dictnode
    method_args: Optional[list[AnonMethodCall]] = None

    def __load__(self, parent: Optional[object] = None) -> object:

        if self._py_object != None:
            return self._py_object

        self.param_node = NodeDict(self.params)

        self.param_node.__load__()

        # ipdb.set_trace()

        return self

    def __call__(self, *args, **kwargs):

        if self._py_object != None:
            return self._py_object

        # ipdb.set_trace()

        module = self.load_module()

        self._py_object = module(**self.param_node())
        self.post_object_creation()
        return self._py_object

    def __init__(self, args: Optional[Bunch], parent: Optional[object] = None):
        super().__init__(args, parent=parent)

    def call_method(self, method_name: str, *args, **kwargs):
        # ipdb.set_trace()
        method_arg_names = [arg["function"] for arg in self.method_args]
        assert method_name in method_arg_names

        idx = method_arg_names.index(method_name)
        method_args = self.method_args[idx]["params"]

        # ipdb.set_trace()

        method_args = load_node(method_args, parent=self)
        method_args.__load__(self)
        method_args = method_args()

        method = getattr(self._py_object, method_name)
        return method(*args, **method_args, **kwargs)


class AnnonymousObject(Node):
    def __init__(self, args: Optional[dict] = None) -> None:
        super().__init__(args)
        setattr(self, "", "")


node_types: list[Type] = [
    Object,
    MethodCall,
    FunctionModuleCall,
    ObjectReference,
    AnonMethodCall,
    NodeDict,
]
SyntaxNode = Union[
    Object, FunctionModuleCall, MethodCall, ObjectReference, AnonMethodCall, NodeDict
]


def load_node(args, parent=None):
    if isinstance(args, dict):
        # ipdb.set_trace()
        node: Optional[SyntaxNode] = None
        for node_type in node_types:
            if node_type.is_one(args):
                node = node_type(args, parent=parent)
                return node

    return args
