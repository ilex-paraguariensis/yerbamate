from importlib.metadata import version

version = version("ymdl")
__version__ = version
