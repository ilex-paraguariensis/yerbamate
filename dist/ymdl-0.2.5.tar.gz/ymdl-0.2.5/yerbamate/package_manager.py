# A Wrapper for managing a package i.e., installing versioning etc.
import os
import sys
import shutil
import urllib
from typing import Union, Callable, Optional, Type
from .bunch import Bunch


import inspect
import ipdb
from .package import Package
from yerbamate import io


class PackageManager:
    @staticmethod
    def load_package_from_configuration(path: str):

        package_args = io.load_json(path)

        package = Package(**package_args)

        return package

