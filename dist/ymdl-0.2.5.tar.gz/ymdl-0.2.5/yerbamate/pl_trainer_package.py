# PL Trainer Package
import os
import sys
import shutil
import urllib
from typing import Union, Callable, Optional, Type
from .bunch import Bunch


import inspect
import ipdb
from yerbamate.package import Package
from yerbamate import parser


class PLTrainerPackage(Package):

    # only params are required
    def __init__(
        self,
        params: Bunch = None,
        root: str = None,
        backbone: str = None,
        source: str = None,
        package: str = None,
        type: str = None,
        url: str = None,
        export: Bunch = None,
        description: str = None,
        version: str = None,
    ):
        super().__init__(
            root=root,
            backbone=backbone,
            source=source,
            package=package,
            type=type,
            url=url,
            params=params,
            export=export,
            description=description,
            version=version,
        )

    def install_objects(self, root_module: str, base_module: str, map_key_values: dict):

        assert (
            "pytorch_lightning_module" and "trainer" and "data" in self.params
        ), "params must contain pytorch_lightning_module, trainer and data"

        # install objects from params
        # ipdb.set_trace()
        objects = parser.load_python_object(
            self.params, self.params.clone(), root_module, base_module, map_key_values
        )

        self.objects = objects

        return objects
