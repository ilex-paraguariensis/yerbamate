
class Constants:
    class File:
        HYPERPARAMETER_FOLDER = 'hyperparameters'
        MODELS_FOLDER = 'models'
        MATE_CONFIG = 'mate.json'
        DATA_LOADER_FOLDER = 'data_loaders'
        DATA_LOADER_FILE = 'data_loader'
        EXEC_FOLDER = 'exec'
        EXEC_FUNCTION = 'run'