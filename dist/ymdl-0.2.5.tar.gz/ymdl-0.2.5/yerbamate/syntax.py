from typing import Optional, Any, Callable, Type, Union
import json

from .bunch import Bunch
import random
import ipdb


class Node:
    object_key: Optional[str] = None
    _py_object: Optional[object] = None

    def __init__(self, args, **kawrgs) -> None:

        if args is None:
            args = self._json()
        for key, val in args.items():
            setattr(self, key, val)

        if self.object_key is None:
            self.object_key = "_rnd_" + "".join(  # it will start with
                random.choice("0123456789abcdef") for n in range(25)
            )

    def _get_python_object(self) -> object:
        pass

    @staticmethod
    def set_config(base_module: str, root_module: str, key_value_map: dict):
        Node._base_module = base_module
        Node._root_module = root_module
        Node._key_value_map = key_value_map

    def post_object_creation(self):
        if "object_key" in self.__dict__:
            Node._key_value_map[self.object_key] = self._py_object

    def load_module(self):

        assert "module" in self.__dict__, "module not found"

        fromlist = [self.class_name] if hasattr(self, "class_name") else []
        fromlist = [getattr(self, "class")] if hasattr(self, "class") else fromlist

        module_list = [
            Node._base_module + "." + self.module,
            Node._root_module + "." + self.module,
            self.module,
        ]

        for module in module_list:
            try:
                module = __import__(module, fromlist=fromlist)
                break
            except ModuleNotFoundError:
                pass

        if module == None:
            raise ModuleNotFoundError(f"module {module} not found")

        if "class" in self:
            module = getattr(module, getattr[self, "class"])
        if "class_name" in self:
            module = getattr(module, getattr[self, "class_name"])

        return module

    def _json(self):
        # returns a simple json representing the node (filtering out private properties and methods)

        def to_json(obj):
            if isinstance(obj, Node):
                return {
                    key: to_json(val)
                    for key, val in obj.__dict__.items()
                    if not key.startswith("_") and not callable(val)
                }
            elif isinstance(obj, list):
                return [to_json(item) for item in obj]
            elif isinstance(obj, dict):
                return {key: to_json(val) for key, val in obj.items()}
            else:
                return obj

        return to_json(self)

    def __str__(self):
        return json.dumps(self._json(), indent=4)

    def __repr__(self):
        return str(self)

    @classmethod
    def _base_json(cls):
        # returns a simple json representing the node (filtering out private properties and methods)
        cur_params = {
            key: val
            for key, val in cls.__dict__.items()
            if not key.startswith("_") and not callable(val)
        }
        for base_class in cls.__bases__:
            if base_class != object:
                cur_params |= {
                    key: val
                    for key, val in base_class.__dict__.items()
                    if not key.startswith("_")
                    and not callable(val)
                    and not (hasattr(val, "__get__") and callable(val.__get__))
                }
        return cur_params

    @classmethod
    def is_one(cls: Type, obj: Any) -> bool:
        # checks that the given object has the same property as the current node
        """
        return isinstance(obj, dict) and (
            sorted(list(obj.keys())) == node_properties
        )
        """
        if not isinstance(obj, dict):
            return False
        for key, val in cls._base_json().items():
            if key not in obj and val is not None:
                return False
        return True

    @classmethod
    def assert_is_one(cls: Type, obj: Any):
        if not cls.is_one(obj):
            raise SyntaxError(
                f"Object {obj} is not a valid node Node. \n This is how it should look like:\n{cls._base_json()}"
            )


class NodeDict(Node):
    def __init__(self, args, **kawrgs) -> None:
        assert type(args) == dict or type(args) == Bunch
        super().__init__(args, **kawrgs)

    def __load__(self, parent: Optional[Node] = None):

        for key, val in self.__dict__.items():
            if isinstance(val, Node):
                val.__load__(self, self)
                setattr(self, key, val())

    def __call__(self, *args: Any, **kwds: Any) -> Any:
        return self.__dict__


class ObjectReference(Node):
    reference_key: str = ""
    _reference: Optional[Node] = None

    def __init__(self, args):
        super().__init__(args)

    def __call__(self, *args: Any, **kwds: Any) -> Any:
        return Node._key_value_map[self.reference_key]


class MethodCall(ObjectReference):
    function_call: str = ""
    reference_key: Optional[str] = None
    params: Bunch = Bunch({})

    def __call__(self, parent: Optional[object] = None, *args, **kwargs):

        # first create DictNode of params
        dictNode = NodeDict(self.params)
        dictNode.__load__(self)

        # then call the function
        object = Node._key_value_map[self.reference_key]
        function = getattr(object, self.function_call)
        return function(*args, **dictNode())

    def __init__(self, args, parent: Optional[object] = None):
        super().__init__(args)


class MethodCall(ObjectReference):
    function: str = ""
    reference_key: Optional[str] = None
    params: Bunch = Bunch({})

    def __call__(self, parent: Optional[object] = None, *args, **kwargs):

        # first create DictNode of params
        dictNode = NodeDict(self.params)
        dictNode.__load__(self)

        # then call the function
        object = Node._key_value_map[self.reference_key]
        function = getattr(object, self.function_call)
        return function(*args, **dictNode())

    def __init__(self, args, parent: Optional[object] = None):
        super().__init__(args)


class Object(Node):
    module: str = ""
    class_name: str = ""
    params: Bunch = Bunch({})  # param is actualy a dictnode
    method_args: Optional[dict[str, MethodCall]] = None

    def __load__(self, parent: Optional[object] = None) -> object:

        if self._py_object != None:
            return self._py_object

        module = self.load_module()

        param_node = NodeDict(self.params)

        param_node.__load__(self)

        self._py_object = module(**param_node())

    def __init__(self, args: Optional[Bunch] = None):
        super().__init__(args)
        # the the object_key is not set, we generate a random one


class LRScheduler(Node):
    monitor: str = ""
    scheduler: Object = Object()  # initialize it because its mandatory

    def __init__(
        self,
        args: Optional[Bunch] = None,
    ) -> None:
        super().__init__(args)
        if args is not None:
            Object.assert_is_one(self.scheduler)
            self.scheduler = Object(self.scheduler)


class Optimizers(Node):
    optimizer: Object = Object()  # initialize it because its mandatory
    lr_scheduler: LRScheduler = LRScheduler()

    def __init__(self, params):
        super().__init__(params)


class AnonMethodCall(Node):
    function: str = ""
    params: Bunch = Bunch({})

    def __load__(self, parent: Node = None) -> object:

        assert parent is not None, "AnonMethodCall must have a parent"

        # first create DictNode of params
        dictNode = NodeDict(self.params)
        dictNode.__load__(self)

        # then call the function
        function = getattr(parent._py_object, self.function)
        return function(**dictNode())

    def __call__(self, parent: Object, *args, **kwargs):
        params_node = NodeDict(self.params)
        params_node.__load__(self)

        return getattr(self._py_object, self.function)(
            *args, **(self.params_node() | kwargs)
        )

    def __init__(self, args, parent: Optional[object] = None):
        super().__init__(args)


class AnnonymousObject(Node):
    def __init__(self, args: Optional[dict] = None) -> None:
        super().__init__(args)
        setattr(self, "", "")


node_types: list[Type] = [
    Object,
    MethodCall,
    ObjectReference,
    LRScheduler,
    Optimizers,
    AnonMethodCall,
]
SyntaxNode = Union[
    Object, MethodCall, ObjectReference, LRScheduler, Optimizers, AnonMethodCall
]
